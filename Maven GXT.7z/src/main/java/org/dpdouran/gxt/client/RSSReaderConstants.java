package org.dpdouran.gxt.client;

public class RSSReaderConstants {
	public static final String FEED_SERVICE = "feedService";
}
