package org.dpdouran.gxt.client;

import com.extjs.gxt.ui.client.widget.ContentPanel;

public class RssMainPanel extends ContentPanel {
	public RssMainPanel() {
		setHeading("Main");
	}
}